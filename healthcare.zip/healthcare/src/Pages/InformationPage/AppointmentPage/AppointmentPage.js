import React from 'react'

const AppointmentPage = () => {
    return (
        <div>
            AppointmentPage
        </div>
    )
}

export default AppointmentPage
