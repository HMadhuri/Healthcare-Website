import React from 'react'

const ExpertPage = () => {
    return (
        <div>
            ExpertPage
        </div>
    )
}

export default ExpertPage
