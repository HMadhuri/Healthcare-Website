
const InformationPage=()=>{
    return(
    
        <div>Information Page</div>
    )
    }
    export default InformationPage;
    